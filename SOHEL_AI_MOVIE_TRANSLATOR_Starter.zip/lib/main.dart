import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

void main() => runApp(const SohelMovieTranslator());

class SohelMovieTranslator extends StatelessWidget {
  const SohelMovieTranslator({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SOHEL AI MOVIE TRANSLATOR',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF090D1B),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF9B6CFF),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const TranslatorHome(),
    );
  }
}

class TranslatorHome extends StatefulWidget {
  const TranslatorHome({super.key});

  @override
  State<TranslatorHome> createState() => _TranslatorHomeState();
}

class _TranslatorHomeState extends State<TranslatorHome> {
  String sourceLanguage = 'Japanese';
  String inputMode = 'upload';
  String? selectedFile;
  final linkController = TextEditingController();
  bool dubbing = true;
  bool subtitles = true;
  bool busy = false;

  @override
  void dispose() {
    linkController.dispose();
    super.dispose();
  }

  Future<void> pickVideo() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.video,
      allowMultiple: false,
    );
    if (result != null && result.files.isNotEmpty) {
      setState(() => selectedFile = result.files.single.name);
    }
  }

  void startTranslation() {
    final hasInput = inputMode == 'upload'
        ? selectedFile != null
        : linkController.text.trim().isNotEmpty;
    if (!hasInput) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(inputMode == 'upload'
              ? 'প্রথমে একটি ভিডিও নির্বাচন করুন'
              : 'প্রথমে ভিডিও লিংক দিন'),
        ),
      );
      return;
    }
    if (!dubbing && !subtitles) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('ডাবিং অথবা সাবটাইটেল চালু করুন')),
      );
      return;
    }
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('পরবর্তী ধাপ প্রস্তুত'),
        content: const Text(
          'ভিডিও ইনপুট নেওয়া হয়েছে। আসল বাংলা ডাবিং ও সাবটাইটেল তৈরির জন্য এখন AI backend/API যুক্ত করতে হবে। এই স্টার্টার অ্যাপে এখনো AI প্রসেসিং চালু নেই।',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('ঠিক আছে'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 18,
        title: const Row(
          children: [
            Icon(Icons.movie_filter_rounded, color: Color(0xFFB99AFF)),
            SizedBox(width: 9),
            Text('SOHEL AI', style: TextStyle(fontWeight: FontWeight.w800)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Settings',
            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('সেটিংস পরবর্তী ধাপে যুক্ত হবে')),
            ),
            icon: const Icon(Icons.settings_outlined),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(26),
                gradient: const LinearGradient(
                  colors: [Color(0xFF342064), Color(0xFF171B3D), Color(0xFF102D43)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border.all(color: Colors.white.withOpacity(.10)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(.12),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: const Text('AI LANGUAGE STUDIO',
                        style: TextStyle(fontSize: 10, letterSpacing: 1.5)),
                  ),
                  const SizedBox(height: 18),
                  const Text('মুভি বুঝুন\\nনিজের ভাষায়',
                      style: TextStyle(fontSize: 29, height: 1.2, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 9),
                  Text('জাপানি • কোরিয়ান • চাইনিজ থেকে বাংলায়',
                      style: TextStyle(color: Colors.white.withOpacity(.78), fontSize: 13)),
                  const SizedBox(height: 18),
                  const Row(
                    children: [
                      _MiniFeature(icon: Icons.record_voice_over, label: 'বাংলা ডাবিং'),
                      SizedBox(width: 9),
                      _MiniFeature(icon: Icons.subtitles, label: 'সাবটাইটেল'),
                    ],
                  )
                ],
              ),
            ),
            const SizedBox(height: 25),
            const _SectionTitle(number: '01', title: 'মূল ভিডিওর ভাষা'),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: sourceLanguage,
              decoration: _decoration('ভিডিওর ভাষা', Icons.translate),
              items: const [
                DropdownMenuItem(value: 'Japanese', child: Text('🇯🇵  Japanese / জাপানি')),
                DropdownMenuItem(value: 'Korean', child: Text('🇰🇷  Korean / কোরিয়ান')),
                DropdownMenuItem(value: 'Chinese', child: Text('🇨🇳  Chinese / চাইনিজ')),
              ],
              onChanged: (v) => setState(() => sourceLanguage = v ?? 'Japanese'),
            ),
            const SizedBox(height: 24),
            const _SectionTitle(number: '02', title: 'মুভি যোগ করুন'),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _ModeButton(
                  label: 'ভিডিও আপলোড',
                  icon: Icons.upload_file_rounded,
                  selected: inputMode == 'upload',
                  onTap: () => setState(() => inputMode = 'upload'),
                )),
                const SizedBox(width: 10),
                Expanded(child: _ModeButton(
                  label: 'ভিডিও লিংক',
                  icon: Icons.link_rounded,
                  selected: inputMode == 'link',
                  onTap: () => setState(() => inputMode = 'link'),
                )),
              ],
            ),
            const SizedBox(height: 12),
            if (inputMode == 'upload')
              InkWell(
                onTap: pickVideo,
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 25, horizontal: 16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF141A2D),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: const Color(0xFF7151B8), width: 1.2),
                  ),
                  child: Column(
                    children: [
                      const Icon(Icons.cloud_upload_outlined, size: 38, color: Color(0xFFB99AFF)),
                      const SizedBox(height: 10),
                      Text(selectedFile ?? 'ভিডিও নির্বাচন করুন',
                          style: const TextStyle(fontWeight: FontWeight.w700)),
                      const SizedBox(height: 5),
                      Text('MP4, MOV, MKV • ফোন থেকে বেছে নিন',
                          style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(.55))),
                    ],
                  ),
                ),
              )
            else
              TextField(
                controller: linkController,
                keyboardType: TextInputType.url,
                decoration: _decoration('ভিডিও URL পেস্ট করুন', Icons.link),
              ),
            const SizedBox(height: 24),
            const _SectionTitle(number: '03', title: 'বাংলা আউটপুট'),
            const SizedBox(height: 12),
            _OutputTile(
              icon: Icons.record_voice_over_rounded,
              title: 'বাংলা AI ডাবিং',
              subtitle: 'মূল কথার বদলে বাংলা কণ্ঠ',
              value: dubbing,
              onChanged: (v) => setState(() => dubbing = v),
            ),
            const SizedBox(height: 10),
            _OutputTile(
              icon: Icons.closed_caption_rounded,
              title: 'বাংলা সাবটাইটেল',
              subtitle: 'ভিডিওতে বাংলা লেখা',
              value: subtitles,
              onChanged: (v) => setState(() => subtitles = v),
            ),
            const SizedBox(height: 24),
            SizedBox(
              height: 56,
              child: FilledButton.icon(
                onPressed: busy ? null : startTranslation,
                icon: const Icon(Icons.auto_awesome_rounded),
                label: const Text('বাংলা অনুবাদ শুরু করুন',
                    style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF8755E8),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)),
                ),
              ),
            ),
            const SizedBox(height: 16),
            const Center(
              child: Text('SOHEL AI • Made for movie lovers',
                  style: TextStyle(color: Colors.white38, fontSize: 11)),
            ),
          ],
        ),
      ),
    );
  }

  InputDecoration _decoration(String hint, IconData icon) => InputDecoration(
    hintText: hint,
    prefixIcon: Icon(icon, color: const Color(0xFFB99AFF)),
    filled: true,
    fillColor: const Color(0xFF141A2D),
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(16),
      borderSide: BorderSide(color: Colors.white.withOpacity(.07)),
    ),
  );
}

class _SectionTitle extends StatelessWidget {
  final String number, title;
  const _SectionTitle({required this.number, required this.title});
  @override
  Widget build(BuildContext context) => Row(
    children: [
      Text(number, style: const TextStyle(color: Color(0xFFB99AFF), fontWeight: FontWeight.w900)),
      const SizedBox(width: 10),
      Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
    ],
  );
}

class _MiniFeature extends StatelessWidget {
  final IconData icon;
  final String label;
  const _MiniFeature({required this.icon, required this.label});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
    decoration: BoxDecoration(color: Colors.white.withOpacity(.12), borderRadius: BorderRadius.circular(12)),
    child: Row(children: [Icon(icon, size: 15), const SizedBox(width: 6), Text(label, style: const TextStyle(fontSize: 11))]),
  );
}

class _ModeButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;
  const _ModeButton({required this.label, required this.icon, required this.selected, required this.onTap});
  @override
  Widget build(BuildContext context) => OutlinedButton.icon(
    onPressed: onTap,
    icon: Icon(icon, size: 18),
    label: Text(label, maxLines: 1),
    style: OutlinedButton.styleFrom(
      foregroundColor: selected ? Colors.white : Colors.white70,
      backgroundColor: selected ? const Color(0xFF39245F) : const Color(0xFF141A2D),
      side: BorderSide(color: selected ? const Color(0xFF9B6CFF) : Colors.white12),
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
  );
}

class _OutputTile extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;
  const _OutputTile({required this.icon, required this.title, required this.subtitle, required this.value, required this.onChanged});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
    decoration: BoxDecoration(
      color: const Color(0xFF141A2D),
      borderRadius: BorderRadius.circular(17),
      border: Border.all(color: Colors.white.withOpacity(.06)),
    ),
    child: Row(children: [
      Container(
        width: 40, height: 40,
        decoration: BoxDecoration(color: const Color(0xFF30234D), borderRadius: BorderRadius.circular(12)),
        child: Icon(icon, color: const Color(0xFFB99AFF)),
      ),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 3),
        Text(subtitle, style: const TextStyle(fontSize: 11, color: Colors.white54)),
      ])),
      Switch(value: value, onChanged: onChanged, activeColor: const Color(0xFFB99AFF)),
    ]),
  );
}
