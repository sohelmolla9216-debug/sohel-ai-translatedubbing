# SOHEL AI MOVIE TRANSLATOR — Android starter

This is a Flutter starter project for a Bengali movie translation app.

## Included in this starter
- Premium dark UI
- Japanese, Korean, Chinese source-language selector
- Choose a video from the phone (file picker)
- Video-link input field
- Bengali dubbing and Bengali subtitle output toggles
- Basic input validation and an honest backend-not-connected notice

## Run on a computer with Flutter installed
1. Extract this ZIP.
2. Open a terminal in this folder.
3. Run `flutter pub get`
4. Run `flutter run`

## Important: AI processing is not connected yet
The current project is a working UI starter, not a finished AI dubbing engine.
To produce real dubbed videos, connect a secure backend that:
1. Accepts authorized video uploads or supported direct media URLs.
2. Extracts audio and transcribes Japanese/Korean/Chinese speech with timestamps.
3. Translates the transcript into Bengali.
4. Generates Bengali speech audio (TTS).
5. Aligns/replaces audio and creates Bengali subtitle files (SRT/VTT).
6. Exports the result and provides a download link.

Keep API keys on the backend. Do not put secret API keys in Flutter code.
Only process videos you own or have permission to translate and dub. Many streaming-site links cannot legally or technically be downloaded/processed; use direct files or authorized sources.

## Next build step
Implement a backend API contract and connect upload/progress/result screens. The video-link field is currently a UI input only; it does not fetch or download a movie.
